#ifndef MYWINDOW_H
#define MYWINDOW_H
#include <QMainWindow>
#include"tower.h"
#include<QList>
#include"myobject.h"
#include"bullet.h"
class Bullet;
class MyWindow;
class Tower;
class MyObject;
class QMainWindow;
#include"tower3.h"
#include"myobject3.h"
#include"bullet3.h"

class MyWindow : public QMainWindow
{
    Q_OBJECT
public:
    explicit MyWindow(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);//ʹ�����ͼƬչ�ֳ���
    void set_tower();//����չ����mywindow
    void set_tower3();
    void set_tower31();
    void set_tower32();
    void set_tower33();
    void addMyObject();
    void addMyObject3();
    void updateScene();//����һ���������½����
    void addBullet();
    void addBullt3();
private:
     QList<Tower*>tower_list;
     QList<MyObject*>object_list;
     QList<Bullet*>bullet_list;
     QList<MyObject3*>object3_list;
     QList<Tower3*>tower3_list;
     QList<Bullet3*>bullet3_list;
signals:
   void chooseBack();
public slots:
protected:
};

#endif // MYWINDOW_H
