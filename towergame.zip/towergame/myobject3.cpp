#include "myobject3.h"
#include"tower.h"
#include<QRect>
#include<QSize>
#include"mywindow.h"
MyObject3::MyObject3(){}
MyObject3::MyObject3(QString fileName):QObject (0),pixmap(fileName)
  {
    this->startPos=pos[0];//������ʼ��
    this->currentPos=startPos;
    this->targetPos=pos[1];
    speed=4.0;//������d
    m_maxHp=20;//Ĭ����40��Ѫ
    m_currentHp=20;//���ڻ�����Ѫ
    m_rotationSprite=0.0;//�����洢���˵���һ������ͼƬ��ת�ĽǶ�

//    startPos(pos[0]),
//       targetPos(pos[1]),speed(8.0),m_maxHp(40),m_currentHp(40),m_rotationSprite(0.0)
}

MyObject3::MyObject3(const MyObject3 & _object)
{
    this->startPos=_object.startPos;
    this->currentPos=_object.currentPos;
    this->targetPos=_object.currentPos;
    this->speed=_object.speed;
    this->m_maxHp=_object.m_maxHp;
    this->m_currentHp=_object.m_currentHp;
    this->m_rotationSprite=_object.m_rotationSprite;
   for(int i=0;i<11;i++)
   {
       this->pos[i]=_object.pos[i];
   }
    this->pixmap=_object.pixmap;
}
void MyObject3::move()
{

   QVector2D vector(targetPos-startPos);//����һ����������ʼλ�õ��յ�
   QVector2D vector1(currentPos-startPos);
   if(vector1.length()<vector.length()){
    vector.normalize();
   currentPos=currentPos+vector.toPoint()*speed;
   }
   else{
       if(i==10)
          {
           return;
       }
       else{
       i++;
       this->startPos=pos[i];
       this->currentPos=startPos;
       this->targetPos=pos[i+1];
       QVector2D vector(targetPos-startPos);
       vector.normalize();
      currentPos=currentPos+vector.toPoint()*speed;
       }
   }


}
void MyObject3::draw(QPainter *painter)
{

   if(m_currentHp>0){
    static const int health_Bar_width=40;//Ѫ���ĳ���
    painter->save();
    QPoint healthBarPoint=currentPos+QPoint(-health_Bar_width+55,-10/3);//Ѫ��������λ��
    //����Ѫ��
    painter->setPen(Qt::NoPen);
    painter->setBrush(Qt::green);//��ɫ�������������̶���С����
    QRect healthBarBackRect(healthBarPoint,QSize(health_Bar_width,2));
    painter->drawRect(healthBarBackRect);
    painter->setBrush(Qt::red);//��ɫ������ǰ����
    QRect healthBarRect(healthBarPoint,QSize((double)m_currentHp/m_maxHp*health_Bar_width,4));
    painter->drawRect(healthBarRect);
    static const QPoint offsetPoint(-10/2,-10/2);
    painter->translate(currentPos);
    painter->rotate(m_rotationSprite);
    painter->drawPixmap(offsetPoint,pixmap);
    painter->restore();

}

}

QPoint MyObject3::getCurrentPos(){

    return this->currentPos;
}
void MyObject3::getDamge(){
    if(currentPos==QPoint(150,500)||currentPos==QPoint(270,390)||
            currentPos==QPoint(360,160)||currentPos==QPoint(600,270)||
            currentPos==QPoint(270,390)||currentPos==QPoint(240,240)||
            currentPos==QPoint(480,210)||currentPos==QPoint(600,270))
    {
        m_currentHp-=10;
    }
}
