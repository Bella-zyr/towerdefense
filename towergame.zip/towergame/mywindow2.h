#ifndef MYWINDOW2_H
#define MYWINDOW2_H


#include <QMainWindow>
#include"tower.h"
#include<QList>
#include"myobject.h"
#include"bullet.h"
#include"myobject2.h"
#include"myobject3.h"
#include"bullet3.h"
#include"tower3.h"
class Bullet;
class MyWindow;
class Tower;
class MyObject;
class QMainWindow;
class MyWindow2 : public QMainWindow
{
    Q_OBJECT
public:
    explicit MyWindow2(QWidget *parent = nullptr);

    void paintEvent(QPaintEvent *);//ʹ�����ͼƬչ�ֳ���
    void set_tower();//����չ����mywindow
   void addMyObject2();
    void updateScene();//����һ���������½����

    void set_tower3();
    void set_tower31();
     //void addMyObject3();
     void addBullet();
     void addBullt3();
private:
    QList<Tower*>tower_list;
    QList<MyObject2*>object2_list;
    QList<Bullet*>bullet_list;
   // QList<MyObject3*>object3_list;
    QList<Tower3*>tower3_list;
    QList<Bullet3*>bullet3_list;
signals:
     void chooseBack();
public slots:
};

#endif // MYWINDOW2_H
