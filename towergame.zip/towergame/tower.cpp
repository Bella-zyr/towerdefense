#include "tower.h"
#include<QPoint>
#include<QPixmap>
#include<QPainter>
#include"bullet.h"
#include"myobject.h"
//const QSize Tower::ms_fixedSize(44,44);
Tower::Tower(QPoint pos,QString pixFilename):QObject (0),pixmap(pixFilename)
{
    _pos=pos;

}
void Tower::draw(QPainter *painter)
{
    painter->drawPixmap(_pos,pixmap);

//    painter->save();
//    painter->setPen(Qt::white);//��ɫ
//    painter->drawEllipse(_pos+QPoint(80,80),m_attackRange,m_attackRange);//���ƹ�����Χ
//    static const QPoint offsetPoint(0/2,0/2);
//    painter->translate(_pos);
//    painter->drawPixmap(offsetPoint,pixmap);//��������
//    painter->restore();
}
