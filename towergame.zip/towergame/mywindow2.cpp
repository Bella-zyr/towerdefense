#include "mywindow2.h"
#include<QPainter>
#include<QPaintEvent>
#include<QPixmap>
#include"mybutton.h"
#include"tower.h"
#include<QTimer>
#include<QDebug>
#include"bullet.h"
#include<QMediaPlayer>
#include"mywindow.h"
#include<QTimer>
MyWindow2::MyWindow2(QWidget *parent) : QMainWindow(parent)
{
    setFixedSize(800,600);
    Mybutton *back_btn=new Mybutton(":/button.png");//���밴ť��ͼƬ
    back_btn->setParent(this);
    back_btn->move(700,500);//���ذ�ť��λ��

    Mybutton *setTower=new Mybutton(":/button.png");//�����ť֮�󴥷�������
    setTower->setParent(this);
    setTower->move(130,400);//���õ�����λ��
     connect(setTower,&Mybutton::clicked,this,[=](){
         this->set_tower();
         QTimer *timer0=new QTimer(this);
         connect(timer0,&QTimer::timeout,this,&MyWindow2::addBullet);
         timer0->start(1000);
    });//���°�ť�����ֲ���ʼ����

//    Mybutton *setplayer=new Mybutton(":/button.png");//�����ť
//    setplayer->setParent(this);
//    setplayer->move(50,10);
//   connect(setplayer,&Mybutton::clicked,this,&MyWindow2::addMyObject2);//�����ť֮����ҳ���

    connect(back_btn,&Mybutton::clicked,this,[=](){
        emit chooseBack();//���ذ�ť

    });

      QTimer * timer=new QTimer(this);//����һ��ʱ�䣬ʹ�����ܹ���������
      connect(timer,&QTimer::timeout,this,&MyWindow2::updateScene);
      timer->start(100);//���ø���ʱ����

      Mybutton *setplayer=new Mybutton(":/button.png");//�����ť
      setplayer->setParent(this);
      setplayer->move(50,10);
      connect(setplayer,&Mybutton::clicked,this,[=](){
          QTimer *timer0=new QTimer(this);
         connect(timer0,&QTimer::timeout,this,&MyWindow2::addMyObject2);
         timer0->start(2500);
      });
      Mybutton *setTower3=new Mybutton(":/button.png");//�����ť֮�󴥷�������
      setTower3->setParent(this);
      setTower3->move(500,200);//���õİ�ť��λ��
      connect(setTower3,&Mybutton::clicked,this,[=](){
          this->set_tower3();
           QTimer *timer3=new QTimer(this);
           connect(timer3,&QTimer::timeout,this,&MyWindow2::addBullt3);
           timer3->start(1000);
      });//���°�ť�����ֲ���ʼ����

      Mybutton *setTower31=new Mybutton(":/button.png");//�����ť֮�󴥷�������
      setTower31->setParent(this);
      setTower31->move(700,100);//���õİ�ť��λ��
      connect(setTower31,&Mybutton::clicked,this,[=](){
          this->set_tower31();
           QTimer *timer31=new QTimer(this);
           connect(timer31,&QTimer::timeout,this,&MyWindow2::addBullt3);
           timer31->start(1000);
      });//���°�ť�����ֲ���ʼ����

}
void MyWindow2::paintEvent(QPaintEvent *)
{
    QPainter painter1(this);
    QPixmap pixmap(":/secondpic.png");//����һ��ͼƬ����Ϊ������Ϸ�Ľ���
    painter1.drawPixmap(0,0,this->width(),this->height(),pixmap);

    QPainter painter2(this);//ʹ��չ�ֳ���
    foreach(Tower *tower,tower_list)
        tower->draw(&painter2);
    foreach(Tower3 * tower3,tower3_list)
        tower3->draw(&painter2);
    foreach(MyObject2 * object,object2_list)
    {
        object->draw(&painter2);
        object->getDamge();
    }

    foreach(Bullet * bullet,bullet_list)
    {
        if(bullet->getCurrentPos()!=QPoint(10,300))
       {
            if(bullet->getCurrentPos()!=QPoint(170,200))
            {
              if(bullet->getCurrentPos()!=QPoint(430,80))
              {
                 bullet->draw(&painter2);
               }
            }
         }
        else {}
   }

   foreach(Bullet3 * bullet3,bullet3_list)
   {
       if(bullet3->getCurrentPos()!=QPoint(600,80))
      {
           if(bullet3->getCurrentPos()!=QPoint(600,200))
           {
               bullet3->draw(&painter2);
           }
        }
       else {}
   }
}
void MyWindow2::set_tower()
{
    Tower *a_new_tower1=new Tower(QPoint(100,300),":/towerpic.png");//��������ͼƬ
    tower_list.push_back(a_new_tower1);
    Tower *a_new_tower2=new Tower(QPoint(400,300),":/towerpic.png");//��������ͼƬ
    tower_list.push_back(a_new_tower2);
    Tower *a_new_tower3=new Tower(QPoint(250,60),":/towerpic.png");//��������ͼƬ
    tower_list.push_back(a_new_tower3);
    update();
}
void MyWindow2::addMyObject2()
{
    MyObject2 * object=new MyObject2(":/player.png");//������ҵ�ͼƬ
    object->getDamge();
    object2_list.push_back(object);
    update();
}
void MyWindow2::updateScene()//����һ�����½���ĺ�������������
{
    foreach(MyObject2 * object,object2_list)
    object->move();
    update();
}
void MyWindow2::set_tower3()
{
    Tower3 * tower3=new Tower3(QPoint(480,150),":/tower3.png");
    tower3_list.push_back(tower3);
    update();
}
void MyWindow2::set_tower31()
{
    Tower3 * tower31=new Tower3(QPoint(700,100),":/tower3.png");
    tower3_list.push_back(tower31);
    update();
}
void MyWindow2::addBullet()
{

    Bullet * bullet1=new Bullet(QPoint(100,300),QPoint(10,300),":/bullet.png");
    bullet_list.push_back(bullet1);
    bullet1->move();

    Bullet * bullet2=new Bullet(QPoint(400,300),QPoint(170,200),":/bullet.png");
    bullet_list.push_back(bullet2);
    bullet2->move();

    Bullet * bullet3=new Bullet(QPoint(250,60),QPoint(430,80),":/bullet.png");
    bullet_list.push_back(bullet3);
    bullet3->move();

}
void MyWindow2::addBullt3()
{
    Bullet3 * bullet1=new Bullet3(QPoint(500,250),QPoint(600,80),":/bullet3.png");
    bullet3_list.push_back(bullet1);
    bullet1->move();

    Bullet3 * bullet2=new Bullet3(QPoint(700,120),QPoint(600,200),":/bullet3.png");
    bullet3_list.push_back(bullet2);
    bullet2->move();

}
