#ifndef TOWER3_H
#define TOWER3_H

#include <QObject>
#include<QPoint>
#include<QPixmap>
#include<QSize>
#include"myobject.h"
#include<QTimer>
//#include"mywindow.h"


class MyWindow;
class MyObject;

class Tower3 : public QObject
{
    Q_OBJECT
public:
    Tower3(QPoint pos,QString pixFilename);
     void draw(QPainter *painter);


private:
     QPoint _pos;//λ��
     QPixmap pixmap;
     int m_attackRange;//������Χ
     int m_fireRate;//����pinl
     int m_damage;//�����˺�ֵ
     //static const QSize ms_fixedSize;
     double m_rationpixmap;

private slots:

};


#endif // TOWER3_H
