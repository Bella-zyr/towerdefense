#ifndef GUANQIA_H
#define GUANQIA_H

#include <QMainWindow>

#include <QMainWindow>
#include"tower.h"
#include<QList>
#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include<QKeyEvent>
#include<QTimer>
#include <QPushButton>
class guanqia : public QMainWindow
{
    Q_OBJECT
public:
    explicit guanqia(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *);
private:
   signals:
void chooseback();//Ҫ��ͨmywindow��MainWindow
public slots:

signals:

public slots:
};

#endif // GUANQIA_H
