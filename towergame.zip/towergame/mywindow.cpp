#include "mywindow.h"
#include<QPainter>
#include<QPaintEvent>
#include<QPixmap>
#include"mybutton.h"
#include"tower.h"
#include<QTimer>
#include<QDebug>
#include"bullet.h"
#include<QMediaPlayer>

MyWindow::MyWindow(QWidget *parent) : QMainWindow(parent)
{
  setFixedSize(800,600);
  Mybutton *back_btn=new Mybutton(":/button.png");//���밴ť��ͼƬ
  back_btn->setParent(this);
  back_btn->move(700,500);//���ذ�ť��λ��

  Mybutton *setTower=new Mybutton(":/button.png");//�����ť֮�󴥷�������
  setTower->setParent(this);
  setTower->move(100,400);//���õ�����λ��
 // connect(setTower,&Mybutton::clicked,this,&MyWindow::set_tower);
  connect(setTower,&Mybutton::clicked,this,[=](){
      this->set_tower();
       QTimer *timer1=new QTimer(this);
       connect(timer1,&QTimer::timeout,this,&MyWindow::addBullet);
       timer1->start(1000);
  });//���°�ť�����ֲ���ʼ����


  connect(back_btn,&Mybutton::clicked,this,[=](){
      emit chooseBack();//���ذ�ť
  });

  Mybutton *setTower3=new Mybutton(":/button.png");//�����ť֮�󴥷�������
  setTower3->setParent(this);
  setTower3->move(270,500);//���õİ�ť��λ��
 // connect(setTower3,&Mybutton::clicked,this,&MyWindow::set_tower3);//��һ��������
  connect(setTower3,&Mybutton::clicked,this,[=](){
      this->set_tower3();
       QTimer *timer3=new QTimer(this);
       connect(timer3,&QTimer::timeout,this,&MyWindow::addBullt3);
       timer3->start(1000);
  });//���°�ť�����ֲ���ʼ����

  Mybutton *setTower31=new Mybutton(":/button.png");//�����ť֮�󴥷�������
  setTower31->setParent(this);
  setTower31->move(180,280);//���õİ�ť��λ��
 // connect(setTower31,&Mybutton::clicked,this,&MyWindow::set_tower31);//�ڶ���������
  connect(setTower31,&Mybutton::clicked,this,[=](){
      this->set_tower31();
       QTimer *timer31=new QTimer(this);
       connect(timer31,&QTimer::timeout,this,&MyWindow::addBullt3);
       timer31->start(1000);
  });//���°�ť�����ֲ���ʼ����

  Mybutton *setTower32=new Mybutton(":/button.png");//�����ť֮�󴥷�������
  setTower32->setParent(this);
  setTower32->move(450,140);//���õİ�ť��λ��
  //connect(setTower32,&Mybutton::clicked,this,&MyWindow::set_tower32);//������������
  connect(setTower32,&Mybutton::clicked,this,[=](){
      this->set_tower32();
       QTimer *timer32=new QTimer(this);
       connect(timer32,&QTimer::timeout,this,&MyWindow::addBullt3);
       timer32->start(1000);
  });//���°�ť�����ֲ���ʼ����

  Mybutton *setTower33=new Mybutton(":/button.png");//�����ť֮�󴥷�������
  setTower33->setParent(this);
  setTower33->move(650,270);//���õİ�ť��λ��
  //connect(setTower33,&Mybutton::clicked,this,&MyWindow::set_tower33);//���ĸ�������

  connect(setTower33,&Mybutton::clicked,this,[=](){
      this->set_tower33();
       QTimer *timer33=new QTimer(this);
       connect(timer33,&QTimer::timeout,this,&MyWindow::addBullt3);
       timer33->start(1000);
  });//���°�ť�����ֲ���ʼ����

      Mybutton *setplayer=new Mybutton(":/button.png");//�����ť
      setplayer->setParent(this);
      setplayer->move(50,10);
      connect(setplayer,&Mybutton::clicked,this,&MyWindow::addMyObject3);
      /*connect(setplayer,&Mybutton::clicked,this,[=](){
        QTimer *timer3=new QTimer(this);
        connect(timer3,&QTimer::timeout,this,&MyWindow::addMyObject3);
        timer3->start(5000);
      });*/
      //�����ť֮����ҳ���

        QTimer *timer0=new QTimer(this);
       connect(timer0,&QTimer::timeout,this,&MyWindow::addMyObject);
       timer0->start(5000);

           QTimer * timer=new QTimer(this);//����һ��ʱ�䣬ʹ�����ܹ���������
           connect(timer,&QTimer::timeout,this,&MyWindow::updateScene);
           timer->start(100);//���ø���ʱ����
}
void MyWindow::paintEvent(QPaintEvent *)
{

    QPainter painter1(this);
    QPixmap pixmap(":/beijing.png");//����һ��ͼƬ����Ϊ������Ϸ�Ľ���
    painter1.drawPixmap(0,0,this->width(),this->height(),pixmap);

    QPainter painter2(this);//ʹ��չ�ֳ���
    foreach(Tower *tower,tower_list)
        tower->draw(&painter2);
        foreach(MyObject * object,object_list)
        {
            object->draw(&painter2);
            object->getDamge();
         }

    foreach(MyObject3 * object3,object3_list)
    {
        object3->draw(&painter2);
        object3->getDamge();
     }

    foreach(Tower3 * tower3,tower3_list)
        tower3->draw(&painter2);

    foreach(Bullet * bullet,bullet_list)
    {
        if(bullet->getCurrentPos()!=QPoint(150,500))
       {
            if(bullet->getCurrentPos()!=QPoint(390,390))
            {
              if(bullet->getCurrentPos()!=QPoint(360,160))
              {
                   if(bullet->getCurrentPos()!=QPoint(600,170))
                   {
                      bullet->draw(&painter2);
                   }
               }
            }
         }
        else {}
   }

   foreach(Bullet3 * bullet3,bullet3_list)
   {
       if(bullet3->getCurrentPos()!=QPoint(270,390))
      {
           if(bullet3->getCurrentPos()!=QPoint(240,240))
           {
             if(bullet3->getCurrentPos()!=QPoint(480,210))
             {
                  if(bullet3->getCurrentPos()!=QPoint(600,270))
                  {
                     bullet3->draw(&painter2);
                  }
              }
           }
        }
       else {}
   }
}

void MyWindow::set_tower()
{
    Tower *a_new_tower1=new Tower(QPoint(50,300),":/towerpic.png");//��������ͼƬ
    tower_list.push_back(a_new_tower1);
    Tower *a_new_tower2=new Tower(QPoint(400,300),":/towerpic.png");//��������ͼƬ
    tower_list.push_back(a_new_tower2);
    Tower *a_new_tower3=new Tower(QPoint(200,60),":/towerpic.png");//��������ͼƬ
    tower_list.push_back(a_new_tower3);
    Tower *a_new_tower4=new Tower(QPoint(650,120),":/towerpic.png");//��������ͼƬ
    tower_list.push_back(a_new_tower4);
    update();
}

void MyWindow::set_tower3()
{
    Tower3 * tower3=new Tower3(QPoint(270,500),":/tower3.png");
    tower3_list.push_back(tower3);
    update();
}
void MyWindow::set_tower31()
{
    Tower3 * tower31=new Tower3(QPoint(180,280),":/tower3.png");
    tower3_list.push_back(tower31);
    update();
}

void MyWindow::set_tower32()
{
    Tower3 * tower32=new Tower3(QPoint(450,140),":/tower3.png");
    tower3_list.push_back(tower32);
    update();
}
void MyWindow::set_tower33()
{
    Tower3 * tower33=new Tower3(QPoint(650,270),":/tower3.png");
    tower3_list.push_back(tower33);
    update();
}
void MyWindow::addMyObject()
{
    MyObject * object=new MyObject(":/player.png");//������ҵ�ͼƬ
    object->getDamge();
    object_list.push_back(object);
    update();
}

void MyWindow::addMyObject3()
{
    MyObject3 * object3=new MyObject3(":/player3.png");//������ҵ�ͼƬ
    object3->getDamge();
    object3_list.push_back(object3);
    update();
}
void MyWindow::updateScene()//����һ�����½���ĺ�������������
{
    foreach(MyObject * object,object_list)
     object->move();
    foreach(MyObject3 * object3,object3_list)
        object3->move();
    update();
}
void MyWindow::addBullet()
{

    Bullet * bullet1=new Bullet(QPoint(100,300),QPoint(150,500),":/bullet.png");
    bullet_list.push_back(bullet1);
    bullet1->move();

    Bullet * bullet2=new Bullet(QPoint(400,300),QPoint(390,390),":/bullet.png");
    bullet_list.push_back(bullet2);
    bullet2->move();

    Bullet * bullet3=new Bullet(QPoint(200,60),QPoint(360,160),":/bullet.png");
    bullet_list.push_back(bullet3);
    bullet3->move();

    Bullet * bullet4=new Bullet(QPoint(650,120),QPoint(600,170),":/bullet.png");
    bullet_list.push_back(bullet4);
    bullet4->move();
    update();
}
void MyWindow::addBullt3()
{
    Bullet3 * bullet1=new Bullet3(QPoint(270,500),QPoint(270,390),":/bullet3.png");
    bullet3_list.push_back(bullet1);
    bullet1->move();

    Bullet3 * bullet2=new Bullet3(QPoint(180,280),QPoint(240,240),":/bullet3.png");
    bullet3_list.push_back(bullet2);
    bullet2->move();

    Bullet3* bullet3=new Bullet3(QPoint(450,140),QPoint(480,210),":/bullet3.png");
    bullet3_list.push_back(bullet3);
    bullet3->move();

    Bullet3 * bullet4=new Bullet3(QPoint(650,270),QPoint(600,270),":/bullet3.png");
    bullet3_list.push_back(bullet4);
    bullet4->move();
    update();
}
