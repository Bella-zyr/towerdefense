#include "tower3.h"
#include<QPoint>
#include<QPixmap>
#include<QPainter>
#include"bullet.h"
#include"myobject.h"
//const QSize Tower::ms_fixedSize(44,44);
Tower3::Tower3(QPoint pos,QString pixFilename):QObject (0),pixmap(pixFilename)
{
    _pos=pos;
    m_attackRange=110;
    m_damage=10;
    m_fireRate=10;
    //m_fireRateTime=0.0;

}
void Tower3::draw(QPainter *painter)
{
    painter->drawPixmap(_pos,pixmap);

    painter->save();
    painter->setPen(Qt::white);//��ɫ
    painter->drawEllipse(_pos+QPoint(20,20),m_attackRange,m_attackRange);//���ƹ�����Χ
    static const QPoint offsetPoint(0/2,0/2);
    painter->translate(_pos);
    painter->drawPixmap(offsetPoint,pixmap);//��������
    painter->restore();
}
