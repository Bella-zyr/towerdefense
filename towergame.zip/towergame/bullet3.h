#ifndef BULLET3_H
#define BULLET3_H

#include <QObject>
#include<QString>
#include<QPropertyAnimation>
#include<QPoint>
#include<QPixmap>
#include<QPainter>
#include <QObject>


class Bullet3 : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QPoint currentPos READ getCurrentPos WRITE setCurrentPos)
public:
    Bullet3(QPoint startPos,QPoint targetPos,QString fileName);

    void move();
    void draw(QPainter * painter);
    QPoint getCurrentPos();
    void setCurrentPos(QPoint pos);
signals:

public slots:
private:
    QPoint startPos;//��ʼλ��
    QPoint targetPos;//�յ�λ��
    QPoint currentPos;//��ǰλ��
    QPixmap pixmap;//�ӵ������ǿ�������ͼƬ�ƶ�

};

#endif // BULLET3_H
