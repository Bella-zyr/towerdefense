#include "myobject2.h"

MyObject2::MyObject2(){}
MyObject2::MyObject2(QString fileName):QObject (0),pixmap(fileName)
{
    this->setpos();//����setpos�е���Щ��
    this->startPos=pos[0];//������ʼ��
    this->currentPos=startPos;
    this->targetPos=pos[1];
    speed=8.0;//�����ٶ�
    m_maxHp=20;//Ĭ����40��Ѫ
    m_currentHp=20;//���ڻ�����Ѫ
    m_rotationSprite=0.0;//�����洢���˵���һ������ͼƬ��ת�ĽǶ�
}

void MyObject2::move()
{
   QVector2D vector(targetPos-startPos);//����һ����������ʼλ�õ��յ�
   QVector2D vector1(currentPos-startPos);
   if(vector1.length()<vector.length()){
    vector.normalize();
   currentPos=currentPos+vector.toPoint()*speed;
   }
   else{
       if(i==9)
          {
           return;
       }
       else{
       i++;
       this->startPos=pos[i];
       this->currentPos=startPos;
       this->targetPos=pos[i+1];
       QVector2D vector(targetPos-startPos);
       vector.normalize();
      currentPos=currentPos+vector.toPoint()*speed;
       }
   }
}
void MyObject2::draw(QPainter *painter)
{
    if(m_currentHp>0){
        static const int health_Bar_width=40;//Ѫ���ĳ���
        painter->save();
        QPoint healthBarPoint=currentPos+QPoint(-health_Bar_width+55,-10/3);//Ѫ��������λ��
        //����Ѫ��
        painter->setPen(Qt::NoPen);
        painter->setBrush(Qt::green);//��ɫ�������������̶���С����
        QRect healthBarBackRect(healthBarPoint,QSize(health_Bar_width,2));
        painter->drawRect(healthBarBackRect);
        painter->setBrush(Qt::red);//��ɫ������ǰ����
        QRect healthBarRect(healthBarPoint,QSize((double)m_currentHp/m_maxHp*health_Bar_width,4));
        painter->drawRect(healthBarRect);
        static const QPoint offsetPoint(-10/2,-10/2);
        painter->translate(currentPos);
        painter->rotate(m_rotationSprite);
        painter->drawPixmap(offsetPoint,pixmap);
        painter->restore();

    }
}
void MyObject2::setpos()
{
    pos[0].setX(0);
    pos[0].setY(300);

    pos[1].setX(170);
    pos[1].setY(300);

    pos[2].setX(170);
    pos[2].setY(200);

    pos[3].setX(430);
    pos[3].setY(200);

    pos[4].setX(430);
    pos[4].setY(80);

    pos[5].setX(600);
    pos[5].setY(80);

    pos[6].setX(600);
    pos[6].setY(200);

    pos[7].setX(800);
    pos[7].setY(200);

    pos[8].setX(1000);
    pos[8].setY(200);

}
void MyObject2::getDamge(){

    if(currentPos==QPoint(10,300)||currentPos==QPoint(170,200)||
            currentPos==QPoint(430,80)||currentPos==QPoint(600,80)||
            currentPos==QPoint(600,200))
    {
        m_currentHp-=10;
    }
    else {
    }
}
