#include "bullet3.h"

#include<QPropertyAnimation>
Bullet3::Bullet3(QPoint startPos,QPoint targetPos,QString fileName) : QObject(0),pixmap(fileName)
{
   this->currentPos=startPos;
    this->startPos=startPos;
    this->targetPos=targetPos;
}
void Bullet3::draw(QPainter *painter)
{

    painter->drawPixmap(currentPos,pixmap);

}
void Bullet3::move()
{
   QPropertyAnimation * animation=new QPropertyAnimation(this,"currentPos");
   animation->setDuration(500);
   animation->setStartValue(startPos);//��ʼ��
   animation->setEndValue(targetPos);//��ֹ��
   animation->start();

}
QPoint Bullet3::getCurrentPos()
{
    return this->currentPos;
}
void Bullet3::setCurrentPos(QPoint pos)
{
    this->currentPos=pos;
}

