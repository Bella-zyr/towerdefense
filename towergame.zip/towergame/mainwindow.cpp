#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include<QKeyEvent>
#include<QTimer>
#include<QPushButton>
#include<QPixmap>
#include<QPaintEvent>
#include<QPainter>
#include"mybutton.h"
#include"mywindow.h"
#include"guanqia.h"
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    this->setFixedSize(800,600);
    ui->setupUi(this);

    Mybutton *btn=new Mybutton(":/btn.png");//���밴ť��ͼƬ
    btn->setParent(this);
    btn->move(200,325);//���ð�ť��λ��
    guanqia * scene =new guanqia;
    connect(btn,&QPushButton::clicked,this,[=](){
        btn->zoomdown();
        btn->zoomup();
        QTimer::singleShot(500,this,[=](){
            this->hide();
             scene->show();
        });

    });
    Mybutton *end_btn=new Mybutton(":/endbutton.png");
    end_btn->setParent(this);
    end_btn->move(670,550);
    connect(end_btn,&QPushButton::clicked,this,&QMainWindow::close);

    connect(scene,&guanqia::chooseback,this,[=](){//�����ť֮���ܹ����ص�֮ǰ��ҳ��
        scene->hide();
        this->show();
    });
    QMediaPlayer * player=new QMediaPlayer;
    player->setMedia(QUrl("qrc:/playyinyue.mp3"));
    player->setVolume(40);
    player->play();
}
MainWindow::~MainWindow()
{
    delete ui;
}
void MainWindow::paintEvent(QPaintEvent *e)
{
    QPainter painter(this);
    QPixmap pixmap(":/startjiemian.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);

}
