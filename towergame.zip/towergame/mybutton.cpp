#include "mybutton.h"
#include<QPixmap>
#include<QPropertyAnimation>
Mybutton::Mybutton(QString pix):QPushButton (0)
{
    QPixmap pixmap(pix);
    this->setFixedSize(pixmap.width(),pixmap.height());
    this->setStyleSheet("QPushButton{border:0px;}");
    this->setIcon(pixmap);
    this->setIconSize(QSize(pixmap.width()/2,pixmap.height()/2));//����ť����Ϊԭ��ͼƬ�д�С��һ��

//    this->setContextMenuPolicy(Qt::ActionsContextMenu);//Ϊ��ť����һ���˵�
//    QAction *action1=new QAction(this);
//    action1->setText("set tower");
//    this->addAction(action1);
//    connect(action1,&QAction::triggered,this,[=](){
//        emit chooseTower();
//    });
}
void Mybutton::zoomdown()//��ť������
{
    QPropertyAnimation *animation=new QPropertyAnimation(this,"geometry");
    animation->setDuration(200);
    animation->setStartValue(QRect(this->x(),this->y(),this->width(),this->height()));
    animation->setEndValue(QRect(this->x(),this->y()+10,this->width(),this->height()));
    animation->setEasingCurve(QEasingCurve::OutBounce);
    animation->start();
}
void Mybutton::zoomup()//ʹ��ť������
{
    QPropertyAnimation *animation=new QPropertyAnimation(this,"geometry");
    animation->setDuration(200);
    animation->setStartValue(QRect(this->x(),this->y()+10,this->width(),this->height()));
    animation->setEndValue(QRect(this->x(),this->y(),this->width(),this->height()));
    animation->setEasingCurve(QEasingCurve::OutBounce);
    animation->start();
}
