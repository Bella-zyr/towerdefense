#ifndef MYBUTTON_H
#define MYBUTTON_H

#include <QWidget>
#include<QPushButton>
#include<QAction>
class Mybutton : public QPushButton
{
    Q_OBJECT
public:
    Mybutton(QString pix);
    void zoomdown();//��ť������
    void zoomup();//��ť������
signals:
  // void chooseTower();
};

#endif // MYBUTTON_H
