#ifndef TOWER_H
#define TOWER_H

#include <QObject>
#include<QPoint>
#include<QPixmap>
#include<QSize>
#include"myobject.h"
#include<QTimer>
//#include"mywindow.h"


class MyWindow;
class MyObject;

class Tower : public QObject
{
    Q_OBJECT
public:
    Tower(QPoint pos,QString pixFilename);
     void draw(QPainter *painter);

     //void attackObject();
     //void targetKilled();
     //void targetObject();
     //void chooseObjectForAttack(MyObject * object);

private:
     QPoint _pos;//λ��
     QPixmap pixmap;
//     int m_attackRange;//������Χ
//     int m_fireRate;//����pinl
//     int m_damage;//�����˺�ֵ
     //static const QSize ms_fixedSize;
//     double m_rationpixmap;
//     MyObject * m_chooseObject;
//     QTimer * m_fireRateTime;
//     MyWindow * m_game;
private slots:
//    void removeBullet();
//    void lostSightObject();
   // void shootWeapon();

};

#endif // TOWER_H
