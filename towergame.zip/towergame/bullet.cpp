#include "bullet.h"
#include<QPropertyAnimation>
Bullet::Bullet(QPoint startPos,QPoint targetPos,QString fileName) : QObject(0),pixmap(fileName)
{
   this->currentPos=startPos;
    this->startPos=startPos;
    this->targetPos=targetPos;
}
void Bullet::draw(QPainter *painter)
{

    painter->drawPixmap(currentPos,pixmap);

}
void Bullet::move()
{
   QPropertyAnimation * animation=new QPropertyAnimation(this,"currentPos");
   animation->setDuration(500);
   animation->setStartValue(startPos);//��ʼ��
   animation->setEndValue(targetPos);//��ֹ��
   animation->start();

}
QPoint Bullet::getCurrentPos()
{
    return this->currentPos;
}
void Bullet::setCurrentPos(QPoint pos)
{
    this->currentPos=pos;
}
