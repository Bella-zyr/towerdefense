#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QImage>
#include <QPainter>
#include<QKeyEvent>
#include<QTimer>
#include <QMainWindow>
#include<QPushButton>
#include<QPixmap>
#include<QPaintEvent>
#include<QPainter>
#include<QMediaPlayer>
#include<QMediaPlaylist>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void paintEvent(QPaintEvent *e);
    void sound();
private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
