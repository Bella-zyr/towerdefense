#ifndef MYOBJECT_H
#define MYOBJECT_H


#include<QPropertyAnimation>
#include<QPoint>
#include<QPixmap>
#include<QPainter>
#include <QObject>
#include<QVector2D>




class MyObject : public QObject
{
    Q_OBJECT
public:
    MyObject(QString fileName);
    MyObject();
    MyObject(const MyObject & _object);
    void move();
    void draw(QPainter * painter);
    void setpos();
    QPoint getCurrentPos();
   void getDamge();
 protected:
    QPoint startPos;//��ʼλ��
    QPoint targetPos;//�յ�λ��
    QPoint currentPos;//��ǰλ��
    QPixmap pixmap;//һ��ͼƬ�����ǿ�������ͼƬ�ƶ�
    qreal speed;//�����ƶ����ٶ�
   int i=0;
    QPoint pos[11]={
        QPoint(150,600),
        QPoint(150,390),
        QPoint(390,390),//2
        QPoint(390,280),
        QPoint(240,280),
        QPoint(240,160),
        QPoint(480,160),
        QPoint(480,270),
        QPoint(600,270),
        QPoint(600,120),
        QPoint(600,-100)
    };
    int m_maxHp;
    int m_currentHp;
    double m_rotationSprite;

signals:


};

#endif // MYOBJECT_H
