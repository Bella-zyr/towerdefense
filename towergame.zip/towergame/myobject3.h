#ifndef MYOBJECT3_H
#define MYOBJECT3_H

#include<QPropertyAnimation>
#include<QPoint>
#include<QPixmap>
#include<QPainter>
#include <QObject>
#include<QVector2D>
class MyObject3 : public QObject
{
    Q_OBJECT
public:
    MyObject3(QString fileName);
    MyObject3();
    MyObject3(const MyObject3 & _object);
    void move();
    void draw(QPainter * painter);
    void setpos();
    QPoint getCurrentPos();
   void getDamge();
 protected:
    QPoint startPos;//��ʼλ��
    QPoint targetPos;//�յ�λ��
    QPoint currentPos;//��ǰλ��
    QPixmap pixmap;//һ��ͼƬ�����ǿ�������ͼƬ�ƶ�
    qreal speed;//�����ƶ����ٶ�
    int i=0;
    QPoint pos[11]={
        QPoint(150,600),
        QPoint(150,440),
        QPoint(390,440),//2
        QPoint(390,320),
        QPoint(240,320),
        QPoint(240,200),
        QPoint(500,200),
        QPoint(500,320),
        QPoint(630,320),
        QPoint(630,120),
        QPoint(630,-100)
    };
    int m_maxHp;
    int m_currentHp;
    double m_rotationSprite;

signals:

public slots:
};

#endif // MYOBJECT3_H
