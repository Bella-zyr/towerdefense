#ifndef MYWINDOW_H
#define MYWINDOW_H

#include <QMainWindow>
#include<QWidget>
#include<QPixmap>
#include<QPaintEvent>
#include"tower.h"
#include<QList>

class Mywindow:public QMainWindow
{
    Q_OBJECT
public:
    explicit Mywindow(QWidget *parent=nullptr);
     void paintEvent(QPaintEvent *);
     void set_tower();
private:
     QList<Tower*>tower_list;
signals:


};

#endif // MYWINDOW_H
