#include "mywindow.h"
#include"mybutton.h"
#include<QPixmap>
#include<QMainWindow>
#include<QWidget>
#include<QPaintEvent>
#include<QPainter>
Mywindow::Mywindow(QWidget * parent) : QMainWindow(parent)
{
    this->setFixedSize(800,600);

    Mybutton *setTower=new Mybutton(":/button.png");
    setTower->setParent(this);
    setTower->move(10,10);
    connect(setTower,&Mybutton::clicked,this,&Mywindow::set_tower);
}
void Mywindow::paintEvent(QPaintEvent *)
{

    QPainter painter(this);
    QPixmap pixmap(":/image/beijing.png");
    painter.drawPixmap(0,0,this->width(),this->height(),pixmap);

    QPainter painter2(this);
    foreach(Tower *tower,tower_list)
        tower->draw(&painter2);

}
void Mywindow::set_tower()
{
    Tower *a_new_tower=new Tower(QPoint(50,300),":/towerpic.png");
    tower_list.push_back(a_new_tower);
    update();

//    Tower *a_new_tower1=new Tower(QPoint(200,70),":/towerpic.png");
//    tower_list.push_back(a_new_tower1);
//    update();
}
